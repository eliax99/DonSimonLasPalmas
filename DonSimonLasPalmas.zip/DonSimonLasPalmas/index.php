<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">

        <style>
            td, table, tr{
                border: 1px solid black;
            }
        </style>

        <title></title>
    </head>
    <body>



        <?php
        session_start();

        
//        if (!isset($_POST['producto0'])) {  // es la primera vez
//            $cesta = [];
//            echo "BIENVENIDO !!!!";
//            $_SESSION['cesta'] = $cesta;
//        } else {          // NO es la primera vez
//            $productos = consultarTodosLosProductos();
//            $cesta =  $_SESSION['cesta'];
//            for ($i = 0; $i < 4; $i++) {
//                $nombre = 'producto' . $i;
//                if ($_POST[$nombre] != 0) {
//                    $productos[$i].setCantidadpedida($_POST[$nombre]);
//                    $cesta[] = $productos[$i];                        
//                    
//                }
//            }
//        }
   //     print_r($_POST);
        echo '<br>';
 //       print_r($cesta);

        include_once 'bd.php';
        include_once 'clases.php';
        $productos = consultarTodosLosProductos();

        echo'  <form method="post" action="comprar.php">';
        $numerofila = 0;
        if ( count($productos) > 0) {
            echo '<table>';
            foreach ($productos as $prod) {
                echo '<tr>';

                echo '<td>';
                echo $prod->getNombre();
                echo '</td>';

                
                
                echo '<td>';
                echo $prod->getPrecio();
                echo '</td>';

                echo '<td>';
                echo $prod->getStock();
                echo '</td>';
                echo '<td>';
                $path = './fotos/' . $prod->getFoto();  
                echo "<img src='$path' width='70' height='70'  >";
            //    $prod->getFoto();
                echo '</td>';

//                echo '<td>';
//                echo "<input type='number' name = 'cajaxxx$numerofila'>";
//                echo '</td>';

                echo '<td>';
                echo "
                    <select name = 'producto$numerofila' >
                      <option value='0'>0</option>
                      <option value='1'>1</option>
                      <option value='2'>2</option>
                      <option value='3'>3</option>
                      <option value='4'>4</option>
                      <option value='5'>5</option>
                      <option value='6'>6</option>
                      <option value='7'>7</option>
                      <option value='8'>8</option>
                      <option value='9'>9</option>
                    </select>";
                echo '</td>';

                echo '</tr>';
                $numerofila++;
            }
            echo '</table>';
        }




        echo "<input type='submit' value='COMPRAR'  name = 'boton$numerofila' >"; //añadir a la cesta

  echo "</form>"; 

             
            echo ' <a href="loginempleados.php" >AREA DE EMPLEADOS</a>';      
        ?>
    </body>
</html>
