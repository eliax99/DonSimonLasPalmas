<?php



class Producto{
    
    private $idprod;
    private $nombre;
    private $precio;
    private $stock;
    private $foto;
    private $cantidadpedida;
    
    function __construct($idprod, $nombre, $precio, $stock, $foto, $cantidadpedida) {
        $this->idprod = $idprod;
        $this->nombre = $nombre;
        $this->precio = $precio;
        $this->stock = $stock;
        $this->foto = $foto;
        $this->cantidadpedida = $cantidadpedida;
    }

    
    function getIdprod() {
        return $this->idprod;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getPrecio() {
        return $this->precio;
    }

    function getStock() {
        return $this->stock;
    }

    function getFoto() {
        return $this->foto;
    }

    function getCantidadpedida() {
        return $this->cantidadpedida;
    }

    function setIdprod($idprod) {
        $this->idprod = $idprod;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setPrecio($precio) {
        $this->precio = $precio;
    }

    function setStock($stock) {
        $this->stock = $stock;
    }

    function setFoto($foto) {
        $this->foto = $foto;
    }

    function setCantidadpedida($cantidadpedida) {
        $this->cantidadpedida = $cantidadpedida;
    }

}

class Pedido{
    
    private $idped;
    private $estado;
    private $emailcliente;
    private $fecha;
    private $listaproductos;

    function __construct($idped, $estado, $emailcliente, $fecha) {
        $this->idped = $idped;
        $this->estado = $estado;
        $this->emailcliente = $emailcliente;
        $this->fecha = $fecha;
    }
    function getIdped() {
        return $this->idped;
    }

    function getEstado() {
        return $this->estado;
    }

    function getEmailcliente() {
        return $this->emailcliente;
    }

    function getFecha() {
        return $this->fecha;
    }

    function getListaproductos() {
        return $this->listaproductos;
    }

    function setIdped($idped) {
        $this->idped = $idped;
    }

    function setEstado($estado) {
        $this->estado = $estado;
    }

    function setEmailcliente($emailcliente) {
        $this->emailcliente = $emailcliente;
    }

    function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    function setListaproductos($listaproductos) {
        $this->listaproductos = $listaproductos;
    }


    

    
    
}


class Cliente{
    
    private $email;
    private $nombre;
    private $direccion;
    private $datospago;
    
    function __construct($email, $nombre, $direccion, $datospago) {
        $this->email = $email;
        $this->nombre = $nombre;
        $this->direccion = $direccion;
        $this->datospago = $datospago;
    }
    function getEmail() {
        return $this->email;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getDireccion() {
        return $this->direccion;
    }

    function getDatospago() {
        return $this->datospago;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

    function setDatospago($datospago) {
        $this->datospago = $datospago;
    }



    
    
}
class Empleado{
    
    private $email;
    private $contrasena;
    private $esadmin;

    function __construct($email, $contrasena, $esadmin) {
        $this->email = $email;
        $this->contrasena = $contrasena;
        $this->esadmin = $esadmin;
    }
    function getEmail() {
        return $this->email;
    }

    function getContrasena() {
        return $this->contrasena;
    }

    function getEsadmin() {
        return $this->esadmin;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setContrasena($contrasena) {
        $this->contrasena = $contrasena;
    }

    function setEsadmin($esadmin) {
        $this->esadmin = $esadmin;
    }





    
    
}