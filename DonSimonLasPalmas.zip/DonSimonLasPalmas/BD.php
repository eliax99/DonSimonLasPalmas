<?php

include_once 'clases.php';

$bbdd = "donsimonlaspalmas";
$usuario = "root";
$password = "";

//session_start();
// CONECTAR -----------
function conectar() {
    global $bbdd, $usuario, $password;
    try {
        $conexion = new PDO("mysql:host=127.0.0.1; dbname=$bbdd; charset=UTF8", $usuario, $password);
        $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conexion;
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    return null;
}

// DESCONECTAR -----------
function desconectar($conexion) {
    try {
        unset($conexion);
    } catch (PDOException $ex) {
        echo "Error al desconectar a la base de datos" . $ex->getMessage();
    }
}

function consultarUnEmpleado($email, $contrasena) {

    try {
        $conexion = conectar();
        $instruccion = $conexion->prepare('Select * from empleado where email = ? and contrasena  = ?');
        $instruccion->bindParam(1, $email);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
        $instruccion->bindParam(2, $contrasena);
        $instruccion->execute();
        if (!$instruccion) {
            return null;
        } else {
            if ($instruccion->rowCount() > 0) {
                $empleasoc = $instruccion->fetch(PDO::FETCH_ASSOC);
                $emple = new Empleado($empleasoc['email'], $empleasoc['contrasena'], $empleasoc['esadmin']);
                return $emple;
            } else {
                return null;
            }
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    } finally {
        desconectar($conexion);
    }
    return null;
}

function consultarUnProducto($idprod) {

    try {
        $conexion = conectar();
        $instruccion = $conexion->prepare('Select * from producto where idprod = ? ');
        $instruccion->bindParam(1, $idprod);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
        $instruccion->execute();
        if (!$instruccion) {
            return null;
        } else {
            if ($instruccion->rowCount() > 0) {
                $prodsoc = $instruccion->fetch(PDO::FETCH_ASSOC);
                $produ = new Producto($prodsoc['idprod'], $prodsoc['nombre'], $prodsoc['precio'], $prodsoc['stock'], $prodsoc['foto'], 0);
                return $produ;
            } else {
                return null;
            }
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    } finally {
        desconectar($conexion);
    }
    return null;
}

function consultarTodosLosProductos() {
    $productos = [];
    try {
        $conexion = conectar();
        $registros = $conexion->query('Select * from Producto'); // obtiene un array ASOCIATIVO donde cada elemento es un registro
        if (!$registros) {
            exit("Error en la consulta");
        } else {
            foreach ($registros as $fila) {
                $prod = new Producto($fila['idprod'], $fila['nombre'], $fila['precio'], $fila['stock'], $fila['foto'], 0);
                $productos[] = $prod;
            }
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    desconectar($conexion);
    return $productos;
}

function consultarTodosLosPedidos() {
    $pedidos = [];
    try {
        $conexion = conectar();
        $registros = $conexion->query('Select * from Pedido'); // obtiene un array ASOCIATIVO donde cada elemento es un registro
        if (!$registros) {
            exit("Error en la consulta");
            return null;
        } else {
            foreach ($registros as $fila) {
                $pedidofinal = new Pedido($fila['idped'], $fila['estado'], $fila['emailcliente'], $fila['fecha']);
                $pedidos[] = $pedidofinal;

                $instruccion2 = $conexion->prepare('Select * from productopedido where idped = ? ');
                $instruccion2->bindParam(1, $fila['idped']);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion2->execute();

                $listaproductos = [];

                foreach ($instruccion2 as $cadaprod) {

                    $idprod = $cadaprod['idprod'];
                    $cantidadpedida = $cadaprod['cantidad'];
                    $elproducto = consultarUnProducto($idprod);
                    $elproducto->setCantidadpedida($cantidadpedida);
                    $listaproductos[] = $elproducto;
                }
                $pedidofinal->setListaproductos($listaproductos);
            }
            return $pedidos;
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    } finally {
        desconectar($conexion);
    }

    return null;
}

function consultarUnPedido($idpedidobuscado) {
    $pedidos = [];
    try {
        $conexion = conectar();
        $registros = $conexion->prepare('Select * from Pedido where idped= ?'); // obtiene un array ASOCIATIVO donde cada elemento es un registro
        $registros->bindParam(1, $idpedidobuscado);
        $registros->execute();

        if (!$registros) {
            exit("Error en la consulta");
            return null;
        } else {
            foreach ($registros as $fila) {
                $pedidofinal = new Pedido($fila['idped'], $fila['estado'], $fila['emailcliente'], $fila['fecha']);

                $instruccion2 = $conexion->prepare('Select * from productopedido where idped = ? ');
                $instruccion2->bindParam(1, $fila['idped']);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion2->execute();

                $listaproductos = [];

                foreach ($instruccion2 as $cadaprod) {
                    //   print_r($cadaprod);
                    $idprod = $cadaprod['idprod'];
                    $cantidadpedida = $cadaprod['cantidad'];
                    $elproducto = consultarUnProducto($idprod);
                    $elproducto->setCantidadpedida($cantidadpedida);
                    $listaproductos[] = $elproducto;
                }
                $pedidofinal->setListaproductos($listaproductos);
            }
            return $pedidofinal;
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    } finally {
        desconectar($conexion);
    }

    return null;
}

function consultarTodosLosPedidosDeUnCliente($emailcliente) {
    $pedidos = [];
    try {
        $conexion = conectar();
        $registros = $conexion->prepare('Select * from Pedido where emailcliente = ?'); // obtiene un array ASOCIATIVO donde cada elemento es un registro
        $registros->bindParam(1, $emailcliente);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
        $registros->execute();
        if (!$registros) {
            exit("Error en la consulta");
            return null;
        } else {
            foreach ($registros as $fila) {

             

                $pedidofinal = new Pedido($fila['idped'], $fila['estado'], $fila['emailcliente'], $fila['fecha']);
                $pedidos[] = $pedidofinal;

                // falta meter los productos
                $instruccion2 = $conexion->prepare('Select * from productopedido where idped = ? ');
                $instruccion2->bindParam(1, $fila['idped']);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion2->execute();

                $listaproductos = [];

                foreach ($instruccion2 as $cadaprod) {

                    $idprod = $cadaprod['idprod'];
                    $cantidadpedida = $cadaprod['cantidad'];
                    $elproducto = consultarUnProducto($idprod);
                    $elproducto->setCantidadpedida($cantidadpedida);
                    $listaproductos[] = $elproducto;
                }
                $pedidofinal->setListaproductos($listaproductos);
            }
            return $pedidos;
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    } finally {
        desconectar($conexion);
    }

    return null;
}

function hacerPedido() {

    try {
        $conexion = conectar();

        $cesta = unserialize($_SESSION['cesta']);
        $cliente = $_SESSION['cliente'];

        $emailcli = $cliente->getEmail();

        $registros = $conexion->query("Select * from cliente where email = '$emailcli' ");
        if (!$registros) {
            exit("Error en la consulta");
        } else {

            if ($registros->rowCount() > 0) {
                // ya existe como cliente, se actualiza   
                $sql = "UPDATE CLIENTE SET direccion=? , datospago = ?  where email=?";
                $instruccion = $conexion->prepare($sql);

                $e = $cliente->getEmail();      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS

                $d = $cliente->getDireccion();
                $dp = $cliente->getDatospago();
                $instruccion->bindParam(3, $e);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS

                $instruccion->bindParam(1, $d);
                $instruccion->bindParam(2, $dp);

                $instruccion->execute();
            } else {
                // no existe como cliente, se introduce en la tabla cliente 
                $sql = "INSERT INTO CLIENTE VALUES(?,?,?,?)";
                $instruccion = $conexion->prepare($sql);

                $e = $cliente->getEmail();      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $n = $cliente->getNombre();
                $d = $cliente->getDireccion();
                $dp = $cliente->getDatospago();

                $instruccion->bindParam(1, $e);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion->bindParam(2, $n);
                $instruccion->bindParam(3, $d);
                $instruccion->bindParam(4, $dp);

                $instruccion->execute();
            }


            //  añadir registrop en pedidos
            // no existe como cliente, se introduce en la tabla cliente 
            $sql = "INSERT INTO PEDIDO VALUES(0,0,?,SYSDATE())";
            $instruccion = $conexion->prepare($sql);
            $e = $cliente->getEmail();      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
            $instruccion->bindParam(1, $e);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
            $instruccion->execute();

            $last_id_de_ped = $conexion->lastInsertId();

            foreach ($cesta as $prod) {
                $sql = "INSERT INTO PRODUCTOPEDIDO VALUES(?,?,?)";
                $instruccion = $conexion->prepare($sql);
                $e = $prod->getIdprod();      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $can = $prod->getCantidadpedida();      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion->bindParam(1, $last_id_de_ped);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion->bindParam(2, $e);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion->bindParam(3, $can);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
                $instruccion->execute();
            }
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    desconectar($conexion);
}

function altaproducto($n, $p, $s, $f) {
       try {
        $conexion = conectar();
    
    $sql = "INSERT INTO PRODUCTO VALUES(0,?,?,?,?)";
    $instruccion = $conexion->prepare($sql);

    $instruccion->bindParam(1, $n);      // CUIDADO: BINDPARAM SOLO PERMITE VARIABLES, NO VALORES DIRECTOS
    $instruccion->bindParam(2, $p);
    $instruccion->bindParam(3, $s);
    $instruccion->bindParam(4, $f);
    $instruccion->execute();
        } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    desconectar($conexion);
}

function completarPedido($idpedido) {
    try {
        $conexion = conectar();

        $sql = "UPDATE PEDIDO SET ESTADO = 1 where idped=?";
        $instruccion = $conexion->prepare($sql);
        $instruccion->bindParam(1, $idpedido);

        $instruccion->execute();
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    desconectar($conexion);
}

function selectSimple($instruccionSelectSql) {
    $registros = [];
    try {
        $conexion = conectar();
        $registros = $conexion->query($instruccionSelectSql); // obtiene un array ASOCIATIVO donde cada elemento es un registro
        if (!$registros) {
            exit("Error en la consulta");
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    desconectar($conexion);
    return $registros;
//     $arrayasoc = $registros->fetch(PDO::FETCH_ASSOC);
//     return $arrayasoc; // devuelve un array ASOCIATIVO donde cada elemento es un registro
}
