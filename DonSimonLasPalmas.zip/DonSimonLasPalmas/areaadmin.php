<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">

        <style>
            td, table, tr{
                border: 1px solid black;
            }
        </style>

        <title></title>
    </head>
    <body>
        <?php
        session_start();
        include_once 'bd.php';

        if (isset($_POST['nombreproductonuevo'])) {
            // segunda vez, vengo a dar de alta
            altaproducto($_POST['nombreproductonuevo'], $_POST['precioproductonuevo'], $_POST['stockproductonuevo'], $_POST['fotoproductonuevo']);

            listaprodadmin();
        } else {

            listaprodadmin();
        }

        function listaprodadmin() {

            echo '<br>';

            include_once 'bd.php';
            include_once 'clases.php';
            $productos = consultarTodosLosProductos();
            echo'  <form method="post" action="comprar.php">';
            $numerofila = 0;
            if (count($productos) > 0) {
                echo '<table>';
                foreach ($productos as $prod) {
                    echo '<tr>';

                    echo '<td>';
                    echo $prod->getNombre();
                    echo '</td>';

                    echo '<td>';
                    echo $prod->getPrecio();
                    echo '</td>';

                    echo '<td>';
                    echo $prod->getStock();
                    echo '</td>';
                    echo '<td>';
                    $path = './fotos/' . $prod->getFoto();
                    echo "<img src='$path' width='70' height='70'  >";
                    //    $prod->getFoto();
                    echo '</td>';

                    echo '</tr>';
                    $numerofila++;
                }
                echo '</table>';
            }




            //      echo "<input type='submit' value='COMPRAR'  name = 'boton$numerofila' >"; //añadir a la cesta

            echo "</form>";

            echo ' <a href="nuevoproducto.php" >NUEVO PRODUCTO</a>';
            echo '<BR>';
            echo ' <a href="index.php" >VOLVER A INICIO</a>';
        }
        ?>
    </body>
</html>
