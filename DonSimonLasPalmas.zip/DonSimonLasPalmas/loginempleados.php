<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">

        <style>
            td, table, tr{
                border: 1px solid black;
            }
        </style>

        <title></title>
    </head>
    <body>



        <?php
        session_start();
        include_once 'bd.php';
        include_once 'clases.php';


        if (isset($_POST['email'])) {
            // SEFGUNDA VEZ
            // coger datos del form
            $email = $_POST['email'];
            $contrasena = $_POST['contrasena'];
            // mifrar en la bbdd si esta ese usuario
            $empleadobuscado = consultarUnEmpleado($email, $contrasena);
            if ($empleadobuscado == null) {
                echo 'Datos incorrectos';

                formempleado();
            } else {
                     // si esta, ver si es admin o emple y mandarle a su lado
                if($empleadobuscado->getEsadmin() == 1){
                    //es admin
                    header("Location: areaadmin.php" ); 
                    exit();  
                }else{
                    //es empleado corriente
                    header("Location: areaempleado.php" ); 
                    exit();  
                }
            }



       
        } else {

            // PRIMERA VEZ
            formempleado();
            echo ' <a href="index.php" >VOLVER A INICIO</a>';
        }

        function formempleado() {
            echo'  <form method="post" action="loginempleados.php">';



            echo "EMAIL: <input type='text'  name = 'email' > <BR>";
            echo "CONTRASEÑA: <input type='text'  name = 'contrasena' > <BR>";

            echo "<input type='submit' value='ACCEDER'  name = 'botonacceder' >"; //añadir a la cesta

            echo "</form>";
        }
        ?>
    </body>
</html>
