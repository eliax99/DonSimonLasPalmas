<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">

        <style>
            td, table, tr{
                border: 1px solid black;
            }
        </style>

        <title></title>
    </head>
    <body>



        <?php
        session_start();
        echo '<br>';
        include_once 'bd.php';
        include_once 'clases.php';

        // TODO no se puede completar si ya esta completado




        $idpedidobuscado = $_GET['idpedido'];

        $pedido = consultarUnPedido($idpedidobuscado);

        $productos = $pedido->getListaproductos();
        $_SESSION['IDPEDIDOPARACOMPLETAR'] = $_GET['idpedido'];

   

        echo "<br>LISTA DE PRODUCTOS<br>";
        if ($pedido != null) {
            echo'  <form method="post" action="areaempleado.php">';

            echo '<table>';
            foreach ($productos as $prod) {
                echo '<tr>';

                echo '<td>';
                echo $prod->getNombre();
                echo '</td>';

                echo '<td>';
                echo $prod->getPrecio();
                echo '</td>';

                echo '<td>';
                echo $prod->getStock();
                echo '</td>';

                echo '<td>';
                $path = './fotos/' . $prod->getFoto();  
                echo "<img src='$path' width='50' height='60'  >";
            //    $prod->getFoto();
                echo '</td>';

                echo '<td>';
                echo $prod->getCantidadpedida();
                echo '</td>';


                echo '</tr>';
            }
            echo '</table>';


            echo "<input type='submit' value='VOLVER'  >";
            echo "<input type='submit' name='HAY_QUE_COMPLETAR' value='COMPLETAR Y VOLVER'  >";

            echo "</form>";
        } else {
            echo ' NO HAY PEDIDOS';
            echo ' <a href="index.php" >VOLVER A INICIO</a>';
        }
        ?>
    </body>
</html>


