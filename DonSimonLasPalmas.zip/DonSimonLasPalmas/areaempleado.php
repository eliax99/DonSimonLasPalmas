<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">

        <style>
            td, table, tr{
                border: 1px solid black;
            }
        </style>

        <title></title>
    </head>
    <body>



        <?php
        session_start();
        echo '<br>';
        include_once 'bd.php';
        include_once 'clases.php';


        

        if (isset($_POST['HAY_QUE_COMPLETAR'])) {
            // venimos de consutlar lor productos y henmos decidido completar el pedido
            $idpedido = $_SESSION['IDPEDIDOPARACOMPLETAR'];
            $pedido = consultarUnPedido($idpedido);
            
            if($pedido->getEstado() == 0){
                // lo coimpletamos
                echo "PEDIDO COMPLETADO";
                
                completarPedido($pedido->getIdped());
                
                
            }else{
                // ya estaba copmlpertado 
                echo "EL PEDIDO YA ESTABA COMPLETADO";
            }
            $pedidos = consultarTodosLosPedidos();
        } else if (isset($_POST['buscarporemailcliente'])) {
            //segunda vez 
            $pedidos = consultarTodosLosPedidosDeUnCliente($_POST['buscarporemailcliente']);
        } else {
            //primera vez
            $pedidos = consultarTodosLosPedidos();
        }


        if ($pedidos != null) {
            echo'  <form method="post" action="areaempleado.php">';
            $numerofila = 0;

            echo '<table>';
            echo '<tr>';

            echo '<td>';
            echo 'ID Pedido';
            echo '</td>';

            echo '<td>';
            echo 'Estado';
            echo '</td>';

            echo '<td>';
            echo 'Email';
            echo '</td>';

            echo '<td>';
            echo 'Fecha';
            echo '</td>';


            echo '</tr>';

            foreach ($pedidos as $ped) {
                echo '<tr>';

                echo '<td>';
                $idped = $ped->getIdped();
                echo "<a href='verpedido.php?idpedido=$idped' >" . $idped . "</a>";
                echo '</td>';

                echo '<td>';
                if ($ped->getEstado() == 0) {
                    echo 'Pendiente';
                } else if ($ped->getEstado()) {
                    echo 'Completado';
                }
                echo '</td>';

                echo '<td>';
                echo $ped->getEmailcliente();
                echo '</td>';

                echo '<td>';
                echo $ped->getFecha();
                echo '</td>';


                echo '</tr>';
                $numerofila++;
            }


            echo '</table>';



            echo "<br>BUSCAR POR EMAIL CLIENTE : <input type='text' name='buscarporemailcliente'  >";

            echo "<input type='submit' value='BUSCAR'  >";

            echo "</form>";
        } else {
            echo ' NO HAY PEDIDOS';
        }
        
        echo ' <a href="index.php" >VOLVER A INICIO</a>';
        ?>
        
        
    </body>
</html>


