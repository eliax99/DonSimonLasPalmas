<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">

        <style>
            td, table, tr{
                border: 1px solid black;
            }
        </style>

        <title></title>
    </head>
    <body>



        <?php
        session_start();
        include_once 'bd.php';
        include_once 'clases.php';


        if (isset($_POST['nombre'])) {
            // SEFGUNDA VEZ
            echo ' PEDIDO COMPLETADO <br>';
            echo ' <a href="index.php" >VOLVER A COMPRAR</a>';
            $email = $_POST['email'];
            $nombre = $_POST['nombre'];
            $direccion = $_POST['direccion'];
            $datospago = $_POST['datospago'];
            $cliente = new Cliente($email, $nombre,$direccion,$datospago);
            $_SESSION['cliente'] = $cliente;            
            
            
            
            hacerPedido();
        } else {

            // PRIMERA VEZ


            $cesta = [];


            if (isset($_POST['producto0'])) {  // es la primera vez
               

                $productos = consultarTodosLosProductos();

                for ($i = 0; $i < count($productos); $i++) {
                    $nombre = 'producto' . $i;
                    if ($_POST[$nombre] != 0) {
                        //   print_r($productos[$i]);
                        $productos[$i]->setCantidadpedida($_POST[$nombre]);
                        $cesta[] = $productos[$i];
                    }
                }
            }

     //       $_SESSION['cesta'] = $cesta;
     $_SESSION['cesta'] = serialize($cesta);




            echo'  <form method="post" action="comprar.php">';
            $numerofila = 0;

            echo 'CESTA SOLICITADA: <BR> <table>';
            foreach ($cesta as $prod) {
                echo '<tr>';

                echo '<td>';
                echo $prod->getNombre();
                echo '</td>';

                echo '<td>';
                echo $prod->getPrecio();
                echo '</td>';

                echo '<td>';
                echo $prod->getStock();
                echo '</td>';

                echo '<td>';
                $path = './fotos/' . $prod->getFoto();  
                echo "<img src='$path' width='50' height='60'  >";
            //    $prod->getFoto();
                echo '</td>';

                echo '<td>';
                echo $prod->getCantidadpedida();
                echo '</td>';

                echo '</tr>';
                $numerofila++;
            }
            echo '</table>';

            echo "<BR>";
            echo "<BR>";
            echo "INTRODUZCA SUS DATOS <BR>";
            echo "<BR>";
            echo "EMAIL: <input type='text'  name = 'email' > <BR>";
            echo "NOMBRE: <input type='text'  name = 'nombre' > <BR>";
            echo "DIRECCION : <input type='text'  name = 'direccion' > <BR>";
            echo "NUMERO DE TARJETA : <input type='text'  name = 'datospago' > <BR>";



            echo "<input type='submit' value='COMPRAR'  name = 'boton$numerofila' >"; //añadir a la cesta

            echo "</form>";
            
            echo ' <a href="index.php" >VOLVER A INICIO</a>';
        }
        ?>
    </body>
</html>
