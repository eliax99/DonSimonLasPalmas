<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>


        <?php
        session_start();
        echo '<br>';
        include_once 'bd.php';
        include_once 'clases.php';

        echo'  <form method="post" action="areaadmin.php">';
        
        echo "NUEVO PRODUCTO:";

        echo "<br>NOMBRE : <input type='text' name='nombreproductonuevo'  >";
        echo "<br>PRECIO : <input type='number' name='precioproductonuevo' min='0.1'  step='0.01' >";
        echo "<br>STOCK : <input type='number' name='stockproductonuevo'  >";
        echo "<br>FOTO : <input type='text' name='fotoproductonuevo'  >";

        echo "<input type='submit' value='AÑADIR'  >";
        echo ' <a href="index.php" >VOLVER A INICIO</a>';

        echo "</form>";
        